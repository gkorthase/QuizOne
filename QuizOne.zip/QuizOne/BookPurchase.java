
/**
 * Calculate the bill for book store.
 * @author Gabe Korthase
 * @version 2015.02.02.01
 */
public class BookPurchase
{
    // instance variables - replace the example below with your own
    private int customerAge;
    private double bookCost;
    private String lastName;

    /**
     * Constructor for objects of class BookPurchase
     */
    public BookPurchase()
    {
        customerAge = 0;
        bookCost = 0;
        lastName = "";
    }

    /**
     * How old is the customer?
     */
    public void setCustomerAge(int age)
    {
        customerAge = age;
    }
    
    /**
     * Return the age of the customer.
     */
    public int getCustomerAge() {
        return customerAge;
    }
    
    /**
     * What is the last name of the customer?
     */
    public void setCustomerName(String name) {
        lastName = name;
    }
    
    /**
     * Return the last name of customer.
     */
    public String getCustomerName() {
        return lastName;
    }
    
    /**
     * What was the cost of the customers books?
     */
    public void setBookCost(double cost) {
        bookCost = cost;
    }
    
    /**
     * Return the cost of the books.
     */
    public double getBookCost() {
        return bookCost;
    }
    
    /**
     * Adds sales tax to the cost of the books.
     */
    public void calculateTax(){
        final double tax = .06; //Sales tax
        double temp = 0;
        temp = bookCost * tax;
        bookCost = temp + bookCost;
    }    
}
